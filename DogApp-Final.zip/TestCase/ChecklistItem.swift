//
//  ChecklistItem.swift
//  TestCase
//
//  Created by Jayron Cena on 14/06/2017.
//  Copyright © 2017 최광익. All rights reserved.
//

import Foundation

class ChecklistItem{
    
    var text = ""
    
    var checked = false
    
    func toggleChecked() {
        
        checked = !checked
        
    }
    
}
