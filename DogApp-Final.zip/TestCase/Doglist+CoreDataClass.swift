//
//  DogList+CoreDataClass.swift
//  DataModel
//
//  Created by Gun young Won on 2017. 6. 5..
//  Copyright © 2017년 Gun young Won. All rights reserved.
//

import Foundation
import CoreData

//@objc(Doglist)
public class Doglist: NSManagedObject {

}
